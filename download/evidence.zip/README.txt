Transnorte evidence export
Host: TN-FIN-WS042
Operator: ops.cardoso
Case: IR-2026-0812-SE03
Open invoice.txt for the operator channel and the flag.
The authentic SHA256 is listed next to invoice.txt in SHA256SUMS.
Ignore vendor/ paths they are leftover installer noise.
